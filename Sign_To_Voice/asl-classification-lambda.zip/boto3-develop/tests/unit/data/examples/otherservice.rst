**Other example**

This is for another service
