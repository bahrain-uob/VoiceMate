import json
import awscam
import mo
import cv2
import greengrasssdk
import os
from local_display import LocalDisplay
import speak

def lambda_handler(event, context):
    """Empty entry point to the Lambda function invoked from the edge."""
    return

def infinite_infer_run():
    """ Run the DeepLens inference loop frame by frame"""
    # Create an IoT client for sending to messages to the cloud.
    client = greengrasssdk.client('iot-data')
    iotTopic = '$aws/things/{}/infer'.format(os.environ['AWS_IOT_THING_NAME'])

    # Create a local display instance that will dump the image bytes to a FIFO
    # file that the image can be rendered locally.
    local_display = LocalDisplay('480p')
    local_display.start()
    
    soundOn = True
    
    # Load the model here
    # Model details
    input_width = 224
    input_height = 224
    model_name = 'image-classification'
    model_type = 'classification'
    
    # Optimize the model
    error, model_path = mo.optimize(model_name,input_width,input_height, aux_inputs={'--epoch': 4})
    # Load the model onto the GPU.
    model = awscam.Model(model_path, {'GPU': 1})
    client.publish(topic=iotTopic, payload="Model loaded")
    
    with open('asl24.txt', 'r') as f:
        labels = [l.rstrip() for l in f]
    pred_label = ""
    pred_prob = 0
    
    client.publish(topic=iotTopic, payload="Inference is starting")
    
    while True:
        # Get a frame from the video stream
        ret, frame = awscam.getLastFrame()
        # Raise an exception if failing to get a frame
        if ret == False:
            raise Exception("Failed to get frame from the stream")
        # Draw a Rectangle in the center
        cv2.rectangle(frame, (932, 516), (1532, 1116), (0, 255, 0), 2)
        # Crop image inside the rectangle
        crop_img = frame[516:1116, 932:1532].copy()
        # Resize frame to the same size as the training set.
        frame_resize = cv2.resize(crop_img, (input_width, input_height))

        predictions = model.doInference(frame_resize)
        parsed_inference_results = model.parseResult(model_type, predictions)

        k = 2
        # Get top k results with highest probabilities
        top_k = parsed_inference_results[model_type][0:k]
        
        pred_label = labels[top_k[0]["label"]]
        pred_prob = top_k[0]["prob"]
        
        client.publish(topic=iotTopic, payload = str(pred_label))

        # Add the label of the top result to the frame used by local display.
        cv2.putText(frame, str(pred_label) + ' ' + str(pred_prob), (10, 70), cv2.FONT_HERSHEY_SIMPLEX, 3, (255, 165, 20), 8)
        
        if(soundOn and pred_prob > 0.7):
            client.publish(topic=iotTopic, payload = "Speak Line")
            speak.speak(pred_label)
        # Set the next frame in the local display stream.
        local_display.set_frame_data(frame)
infinite_infer_run()