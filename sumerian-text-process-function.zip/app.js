const { wordsToNumbers } = require('words-to-numbers');
const posTagger = require('wink-pos-tagger');
const tagger = posTagger();
let response;



function separateNumberIntoUnits(n) {
    var s= n.toString().split('');

    return s.map(function(digit, n) {
        return digit * Math.pow(10, s.length - n - 1);
    });
}

function processNumbers(number) {

    let resultArray = []
    let nArray = separateNumberIntoUnits(number);

    if (number < 100) {
        // Number withing 0-99 (inclusive)
        if ((number >= 0 && number <= 15) || number == 20 || number == 21 || number == 22 || number == 33 || number == 44 ||
            number == 55 || number == 66 || number == 77 || number == 88 || number == 99) {
                // Add Number to array
                resultArray.push(number + '_cd');
            }
        else {
            let tenHandShape = nArray[0] + 'h_cd';
            let addition = nArray[1] + '_cd';
            resultArray.push(tenHandShape); resultArray.push(addition);
        }
    }
    else if (number >= 100 && number < 1000) {
        // Number within 100-999 (inclusive)
        let hundredHandShape = nArray[0]/100 + '_cd';
        resultArray.push(hundredHandShape); resultArray.push('100h_cd');
    
        let subNumber = nArray[1] + nArray[2];
        if(subNumber != 0) {
            if ((subNumber > 0 && subNumber <= 15) || subNumber == 20 || subNumber == 21 || subNumber == 22 || subNumber == 33 || subNumber == 44 ||
            subNumber == 55 || subNumber == 66 || subNumber == 77 || subNumber == 88 || subNumber == 99) {
                    // Add Number to array
                    resultArray.push(subNumber + '_cd');
                }
            else {
                let tenHandShape = nArray[1] + 'h_cd';
                let addition = nArray[2] + '_cd';
                resultArray.push(tenHandShape); resultArray.push(addition);
            }
        }
    }
    else if (number >= 1000 && number < 10000) {
        // Number within 1000-9999 (inclusive)
        let thousandHandShape = nArray[0]/1000 + '_cd';
        resultArray.push(thousandHandShape); resultArray.push('1000h_cd');
    
        let hnCheck = nArray[1] + nArray[2] + nArray[3];
        if(hnCheck != 0) {
            let hnCheck2 = nArray[1]/100;
            if (hnCheck2 != 0) {
                let hundredHandShape = nArray[1]/100 + '_cd';
                resultArray.push(hundredHandShape); resultArray.push('100h_cd');
            }
    
            let subNumber = nArray[2] + nArray[3];
            if(subNumber != 0) {
                if ((subNumber > 0 && subNumber <= 15) || subNumber == 20 || subNumber == 21 || subNumber == 22 || subNumber == 33 || subNumber == 44 ||
                subNumber == 55 || subNumber == 66 || subNumber == 77 || subNumber == 88 || subNumber == 99) {
                        // Add Number to array
                        resultArray.push(subNumber + '_cd');
                    }
                else {
                    let tenHandShape = nArray[2] + 'h_cd';
                    let addition = nArray[3] + '_cd';
                    resultArray.push(tenHandShape); resultArray.push(addition);
                }
            }
        }
    }
    else if (number >= 10000 && number < 100000) {
        // Number within 10000-99999 (inclusive)
        let thSubNumber = (nArray[0] + nArray[1])/1000;
        if ((thSubNumber >= 10 && thSubNumber <= 15) || thSubNumber == 20 || thSubNumber == 21 || thSubNumber == 22 || thSubNumber == 33 ||
            thSubNumber == 44 || thSubNumber == 55 || thSubNumber == 66 || thSubNumber == 77 || thSubNumber == 88 || thSubNumber == 99) {
                resultArray.push(thSubNumber + '_cd'); resultArray.push('1000h_cd');
            }
        else {
            let thHandShape = nArray[0]/1000 + '_cd';
            let addition = nArray[1]/1000 + '_cd';
            resultArray.push(thHandShape); resultArray.push(addition); resultArray.push('1000h_cd');
        }
    
        let hnCheck = nArray[2] + nArray[3] + nArray[4];
        if(hnCheck != 0) {
            let hnCheck2 = nArray[2]/100;
            if(hnCheck2 != 0) {
                let hundredHandShape = nArray[2]/100 + '_cd';
                resultArray.push(hundredHandShape); resultArray.push('100h_cd');
            }
    
            let subNumber = nArray[3] + nArray[4];
            if(subNumber != 0) {
                if ((subNumber > 0 && subNumber <= 15) || subNumber == 20 || subNumber == 21 || subNumber == 22 || subNumber == 33 || subNumber == 44 ||
                subNumber == 55 || subNumber == 66 || subNumber == 77 || subNumber == 88 || subNumber == 99) {
                        // Add Number to array
                        resultArray.push(subNumber + '_cd');
                    }
                else {
                    let tenHandShape = nArray[3] + 'h_cd';
                    let addition = nArray[4] + '_cd';
                    resultArray.push(tenHandShape); resultArray.push(addition);
                }
            }
        }
    }
    else if (number >= 100000 && number < 1000000) {
        // Number within 100000-999999 (inclusive)
        let hundredThousandHandShape = nArray[0]/100000 + '_cd';
        resultArray.push(hundredThousandHandShape); resultArray.push('100000h_cd');
    
        let tenThCheck = nArray[1] + nArray[2] + nArray[3] + nArray[4] + nArray[5];
        if(tenThCheck != 0) {
            let tenThCheck2 = nArray[1] + nArray[2];
            if (tenThCheck2 != 0) {
                let thSubNumber = (nArray[1] + nArray[2])/1000;
                if ((thSubNumber > 0 && thSubNumber <= 15) || thSubNumber == 20 || thSubNumber == 21 || thSubNumber == 22 || thSubNumber == 33 ||
                    thSubNumber == 44 || thSubNumber == 55 || thSubNumber == 66 || thSubNumber == 77 || thSubNumber == 88 || thSubNumber == 99) {
                        resultArray.push(thSubNumber + '_cd'); resultArray.push('1000h_cd');
                    }
                else {
                    let thHandShape = nArray[1]/1000 + 'h_cd';
                    let addition = nArray[2]/1000 + '_cd';
                    resultArray.push(thHandShape); resultArray.push(addition); resultArray.push('1000h_cd');
                }
            }
            let hnCheck = nArray[3] + nArray[4] + nArray[5];
            if(hnCheck != 0) {
                let hnCheck2 = nArray[3];
                if(hnCheck2 != 0) {
                    let hundredHandShape = nArray[3]/100 + '_cd';
                    resultArray.push(hundredHandShape); resultArray.push('100h_cd');
                }
                let subNumber = nArray[4] + nArray[5];
                if(subNumber != 0) {
                    if ((subNumber > 0 && subNumber <= 15) || subNumber == 20 || subNumber == 21 || subNumber == 22 || subNumber == 33 || subNumber == 44 ||
                    subNumber == 55 || subNumber == 66 || subNumber == 77 || subNumber == 88 || subNumber == 99) {
                            // Add Number to array
                            resultArray.push(subNumber + '_cd');
                        }
                    else {
                        let tenHandShape = nArray[4] + 'h_cd';
                        let addition = nArray[5] + '_cd';
                        resultArray.push(tenHandShape); resultArray.push(addition);
                    }
                }
            }
        }
    }
    return resultArray;
}

function processText(rs) {
    var initialArray = [];
    for (var i = 0; i < rs.length; i++) {
        if(rs[i]['lemma'] == null)
            var word = rs[i]['value'].toLowerCase();
        else
            var word = rs[i]['lemma'].toLowerCase();
        var type = rs[i]['pos'].toLowerCase();
        
        if (type == 'cc')   initialArray.push(word + '_' + type);
        if (type == 'cd') {
            let tempArr = processNumbers(word);
            for (let i = 0; i < tempArr.length; i ++)
                initialArray.push(tempArr[i]);
        }
        if (type == 'dt')   initialArray.push(word + '_' + type);
        if (type == 'pdt')  initialArray.push(word + '_' + type);
        if (type == '.' || type == ',' || type == 'pos')  initialArray.push(word + '_sym');     // type . includes . ? and !
        if (type == 'in' || type == 'to')   initialArray.push(word + '_in');
        if (type == 'jj' || type == 'jjr' || type == 'jjs')     initialArray.push(word + '_jj');
        if (type == 'nn' || type == 'nnp' || type == 'nnps')    initialArray.push(word + '_nn');
        if (type == 'nns') {
            initialArray.push(word + '_nn');    // Add the word as a noun
            initialArray.push('+_sym');     // Add the MULTIPLE (+) sign after the word
        }
        if (type == 'prp')  initialArray.push(word + '_' + type);
        if (type == 'prp$') initialArray.push(word + '_' + type);
        if (type == 'md')   initialArray.push(word + '_' + type);
        if (type == 'vb' || type == 'vbd' || type == 'vbg' ||
            type == 'vbn' || type == 'vbp' || type == 'vbz')    initialArray.push(word + '_v');
        if (type == 'rb' || type == 'rbr' || type == 'rbs')     initialArray.push(word + '_rb');
        if (type == 'wdt' || type == 'wp' || type == 'wp$' ||
            type == 'wrb')  initialArray.push(word + '_w');
        if (type == 'uh')   initialArray.push(word + '_' + type);
    };

    return initialArray;
};
exports.lambdaHandler = async (event, context) => {
    
    let text = event.inputText.replace(/,/g,"");
    var wn = wordsToNumbers(text);
    var rs = tagger.tagSentence(wn);
    response = processText(rs);
    return response;
};